var data = [{
	"modelName":"Human Resources",
	"domainId":"steel-wheels/metadata.xmi",
	"modelId":"BV_HUMAN_RESOURCES",
	"modelDescription":"This model contains information about Employees."
},{
	"modelName":"Inventory",
	"domainId":"steel-wheels/metadata.xmi",
	"modelId":"BV_INVENTORY",
	"modelDescription":"This model contains information about products and product inventory."
},{
	"modelName":"Orders",
	"domainId":"steel-wheels/metadata.xmi",
	"modelId":"BV_ORDERS",
	"modelDescription":"This model contains information about customers and their orders."
}];

//alert(data[0]["modelName"]);
